Before running, kindly install JDK Development Kit 22.0.2 (~160 MB):

https://download.oracle.com/java/22/latest/jdk-22_windows-x64_bin.exe



-- FOR THE JAR FILE --
After installing Java, if you encounter problems in running the .jar file, kindly download and run Jarfix (~7 KB):

https://johann.loefflmann.net/downloads/jarfix.exe